<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>World Connection</title>
		<link rel="stylesheet" type="text/css" href="CSS/StylePrincipal.css"/>
	</head>
	<body>
	
	<!--Inicia la cabecera de la pagina-->
		<header class="cabecera" id="main-header">
			<table width="100%" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center"><a href="Principal.html"><img src="Logo de Pagina.png" class="logo"/></a></td>
					<td><h1>World Connection</h1></td>
					<td><input type="search" class="busqueda-header"/><button class="header-botton">Buscar</button</td>
					<td><a href="LoginTienda.php"><img src="Sin título-1.png" class="login"/></a></td>
				</tr>
				<tr>
					<td colspan="7" style="text-align: center;">
						<nav>
							<ul>
								<li><a href="Principal.php" target="contemido">Inicio</a></li>
								<li><a href="PnatllasYMonitores.php" target="contemido">Pantallas y Monitores</a></li>
								<li><a href="CPU.php" target="contemido">CPU</a></li>
								<li><a href="Portatiles.php" target="contemido">Portatiles</a></li>
								<li><a href="Carrito.php" target="contemido">Carrito</a></li>
							</ul>
						</nav>
					</td>
				</tr>
			</table>
		</header>
		
		<iframe src="ContPrincipalAdmin.php" name="contemido" width="100%" height="580"></iframe>
	<!--Termina la cabecera de la pagina-->	
	
	
		
	</body>
</html>