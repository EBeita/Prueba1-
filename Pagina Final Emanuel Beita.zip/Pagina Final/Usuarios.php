<?php
	session_start();
	include_once("DBConexion.php");
	
	$Op="";
	$Resp="";

	$txtUsr="";
	$txtapellido="";
	$numtel="";
	$corusr="";
	$pwdusr="";
	
	if(isset($_POST["txtUsr"])){
		$txtUsr = $_POST["txtUsr"];
	}
	
	if(isset($_POST["txtapellido"])){
		$txtapellido = $_POST["txtapellido"];
	}
	
	if(isset($_POST["numtel"])){
		$numtel = $_POST["numtel"];
	}
	
	if(isset($_POST["corusr"])){
		$corusr = $_POST["corusr"];
	}
	
	if(isset($_POST["pwdusr"])){
		$pwdusr = $_POST["pwdusr"];
	}
	
	/* Inicia la muestra de la tabla y modificacion de la tabla */
	
	if(isset($_POST["btnAgregar"])){
		
		$Op=1;
		$Dml="INSERT INTO Tienda(NomUsuario, ApeUsuario, TelUsuario, CorUsuario, PwdUsuario) ";
		$Dml.="VALUES('$txtUsr', '$txtapellido', '$numtel', '$corusr', '$pwdusr') ";
		
		$Resul= @mysqli_query($Conexion,$Dml);
		
		if(@mysqli_errno($Conexion)==0){
			$Resp=TRUE;
		}
}
	
	if(isset($_POST["btnModificar"])){
	/*Preguntar al profe xq no me deja poner las demas columnas*/	
		$Op=2;
		$Dml="UPDATE Tienda ";
		$Dml.="SET ApeUsuario='$txtapellido', TelUsuario='$numtel', CorUsuario='$corusr', PwdUsuario='$pwdusr' ";
		$Dml.="WHERE NomUsuario= $txtUsr ";
		
		$Resul=@mysqli_query($Conexion,$Dml);
		
		if(@mysqli_errno($Conexion)==0){
			$Resp=TRUE;
		}
	}
	
	if(isset($_POST["btnEliminar"])){
		
		$Op=3;
		$Dml="DELETE FROM Tienda ";
		$Dml.="WHERE NomUsuario= '$txtUsr' ";
		
		
		$Resul=@mysqli_query($Conexion,$Dml);
		
		if(@mysqli_errno($Conexion)==0){
			$Resp=TRUE;
		}
	}
	
	if(isset($_POST["btnActualizar"])){
		
		$Op=4;
		$Sql="SELECT * FROM Tienda ";
		
		$Resul=@mysqli_query($Conexion,$Sql);
		
		$Tabla = "<table border=1>";
		$Tabla .="<tr><th>TipoUsuario</th><th>NomUsuario</th><th>Descripcion</th><th>ConUsuario</th><th>EmUsuario</th></tr>";
		
		while($Fila = @mysqli_fetch_array($Resul,MYSQLI_ASSOC)){
			$Tabla.="<tr>";
			$Tabla.="<td>".$Fila["NomUsuario"]."</td>";
			$Tabla.="<td>".$Fila["ApeUsuario"]."</td>";
			$Tabla.="<td>".$Fila["TelUsuario"]."</td>";
			$Tabla.="<td>".$Fila["CorUsuario"]."</td>";
			$Tabla.="<td>".$Fila["PwdUsuario"]."</td>";
			$Tabla.="</td>";
			$Tabla.="</tr>";
		}
		
		$Tabla .= "</table>";
		
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" type="text/css" href="CSS/InfoUsuarios.css"/>
	</head>
	<body>
		
		<!-- Inicia la interacion del administrador -->
		
		<form id="modiAdmin" name="modiAdmin" action="Usuarios.php" method="post">
		
							<input class="btn" type="submit" name="btnAgregar" id="btnAgregar" value="Agregar"/>
							<input class="btn" type="submit" name="btnModificar" id="btnModificar" value="Modificar"/>
							<input class="btn" type="submit" name="btnEliminar" id="btnEliminar" value="Eliminar"/>
							<input class="btn" type="submit" name="btnActualizar" id="btnActualizar" value="Actualizar"/>

				<table align="left" class="TablaModificar" cellspacing="15"> 
				
					<tr>
						<td align="center"><label>Nombre Usuario:</label></td>
						<td><input type="text" name="txtUsr" id="txtUsr" placeholder="Digite su nombre"/></td>
					</tr>
					
					<tr>
						<td align="center"><label>Apellidos Usuario:</label></td>
						<td><input type="text" name="txtapellido" id="txtapellido" placeholder="Digite su apellido"/></td>
					</tr>
					
					<tr>
						<td align="center"><label>Telefono:</label></td>
						<td><input type="number" name="numtel" id="numtel" placeholder="Digite su numero de telefono" /></td>
					</tr>
					
					<tr>
						<td align="center"><label>Correo:</label></td>
						<td><input type="text" name="corusr" id="corusr" placeholder="Digite su correo"/></td>
					</tr>
					
					<tr>
						<td align="center"><label>Contraceña:</label></td>
						<td><input type="password" name="pwdusr" id="pwdusr" placeholder="Digite su contraseña"/></td>
					</tr>
					
					
					
				</table>
			</form>
			
			<?php 
			if ($Op==1 && $Resp){
				echo("<h3>Resgistro Insertado Satisfactoriamente</h3>");
			}
			
			if ($Op==2 && $Resp){
				echo("<h3>Resgistro Modificado Satisfactoriamente</h3>");
			}
			
			if ($Op==3 && $Resp){
				echo("<h3>Resgistro Eliminado Satisfactoriamente</h3>");
			}
			
			if ($Op==4){
				if(isset($Tabla)){
					echo($Tabla);
				}
			}
		?>
	</body>
</html>