<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>CPU</title>
		<link rel="stylesheet" type="text/css" href="CSS/StyleCPU.css"/>
	</head>
	<body>
	<a href="#main-header"><img class="botonSubir" src="https://cdn.pixabay.com/photo/2013/07/12/19/20/arrow-154593_640.png" /></a>
	<!--Empieza la Primera tabla-->
	
	<table>
		<tr>
			<td>
			
			<!--Primer contenedor de Informacion-->
		<div class="contenedor-1" id="main-header">
		
			<img class="img-box" src="https://www.efe.com.pe/media/catalog/product/s/g/sgmp40_1.jpg?quality=80&bg-color=255,255,255&fit=bounds&height=700&width=700&canvas=700:700"/>
			
			<div class="text-info1">
				<table class="tabla-precios">
					<tr>
						<td class="presio" align="center"><b>¢185.000</b></td>
					</tr>
					
					<tr>
						<td>PC GAMING <br/>Intel Core i5</td>
					</tr>	
					
					<tr>
						<td align="center" ><a href="Carrito.html"><img class="carrito" src="https://png.pngtree.com/png-clipart/20230811/original/pngtree-shopping-cart-icon-button-buy-add-vector-picture-image_10348063.png" width="80px"/></a></td>
					</tr>
				</table>	
			</div>

		</div>
		
			</td>
		
			<td>
				<!--Segundo contenedor de Informacion-->
		<div class="contenedor-2">
		
			<img class="img-box" src="https://5.imimg.com/data5/SELLER/Default/2021/6/QB/RA/PO/115177401/amd-ryzen-3-4350g-gaming-pc-cpu-computer--500x500.jpg"/>
			
			<div class="text-info2">
				<table class="tabla-precios">
					<tr>
						<td class="presio" align="center"><b>¢205.000</b></td>
					</tr>
					
					<tr>
						<td>PC GAMING <br/>Raysen5 5600G</td>
					</tr>	
					
					<tr>
						<td align="center" ><a href="Carrito.html"><img class="carrito" src="https://png.pngtree.com/png-clipart/20230811/original/pngtree-shopping-cart-icon-button-buy-add-vector-picture-image_10348063.png" width="80px"/></a></td>
					</tr>
				</table>	
			</div>

		</div>
		
			</td>
			
			<td>
				<!--Tercera contenedor de Informacion-->
		<div class="contenedor-3">
		
			<img class="img-box" src="https://5.imimg.com/data5/FH/GR/KT/SELLER-29014252/gaming-cpu-cabinate.jpg"/>
			
			<div class="text-info2">
				<table class="tabla-precios">
					<tr>
						<td class="presio" align="center"><b>¢368.568</b></td>
					</tr>
					
					<tr>
						<td>PC GAMING <br/> Intel Core i7 - TG Envidia</td>
					</tr>	
					
					<tr>
						<td align="center" ><a href="Carrito.html"><img class="carrito" src="https://png.pngtree.com/png-clipart/20230811/original/pngtree-shopping-cart-icon-button-buy-add-vector-picture-image_10348063.png" width="80px"/></a></td>
					</tr>
				</table>	
			</div>

		</div>
		
			</td>
		
		
		</tr>
	</table>
	
	<!--Termina primera tabla-->
	
	<hr>
	
	<!--Empieza segunda tabla-->
	<table>
		<tr>
			<td>
			
			<!--Primer contenedor de Informacion-->
		<div class="contenedor-1">
		
			<img class="img-box" src="https://cdn.goconqr.com/uploads/node/image/60597189/desktop_cfc516a9-d166-4912-963a-a5dc9e13116f.jpg"/>
			
			<div class="text-info1">
				<table class="tabla-precios">
					<tr>
						<td class="presio" align="center"><b>¢115.000</b></td>
					</tr>
					
					<tr>
						<td>PC Oficina <br/>4GB RAM - Corei5</td>
					</tr>	
					
					<tr>
						<td align="center" ><a href="Carrito.html"><img class="carrito" src="https://png.pngtree.com/png-clipart/20230811/original/pngtree-shopping-cart-icon-button-buy-add-vector-picture-image_10348063.png" width="80px"/></a></td>
					</tr>
				</table>	
			</div>

		</div>
		
			</td>
		
			<td>
				<!--Segundo contenedor de Informacion-->
		<div class="contenedor-2">
		
			<img class="img-box" src="https://intercompras.com/product_thumb.php?img=images/product/HP_Z2F86LT_ABM.jpg&w=380&h=320"/>
			
			<div class="text-info2">
				<table class="tabla-precios">
					<tr>
						<td class="presio" align="center"><b>¢87.500</b></td>
					</tr>
					
					<tr>
						<td>PC Mini <br/>Recomendado para espacios pequeños</td>
					</tr>	
					
					<tr>
						<td align="center" ><a href="Carrito.html"><img class="carrito" src="https://png.pngtree.com/png-clipart/20230811/original/pngtree-shopping-cart-icon-button-buy-add-vector-picture-image_10348063.png" width="80px"/></a></td>
					</tr>
				</table>	
			</div>

		</div>
		
			</td>
			
			<td>
				<!--Tercera contenedor de Informacion-->
		<div class="contenedor-3">
		
			<img class="img-box" src="https://http2.mlstatic.com/D_NQ_NP_859387-MLA74591568644_022024-O.webp"/>
			
			<div class="text-info2">
				<table class="tabla-precios">
					<tr>
						<td class="presio" align="center"><b>¢102.990</b></td>
					</tr>
					
					<tr>
						<td>PC MINI <br/>Conexion a Internet Inalambrica</td>
					</tr>	
					
					<tr>
						<td align="center" ><a href="Carrito.html"><img class="carrito" src="https://png.pngtree.com/png-clipart/20230811/original/pngtree-shopping-cart-icon-button-buy-add-vector-picture-image_10348063.png" width="80px"/></a></td>
					</tr>
				</table>	
			</div>

		</div>
		
			</td>
		
		
		</tr>
	</table>
	
	<!--Terminara la Tercera tabla-->
	
	<footer class="pie-pagina">
			<table class="tabla-contactanos" align="center" cellspacing="40">
				<tr>
					<td align="center"><img src="https://cdn.pixabay.com/photo/2021/10/17/14/55/instagram-6718540_1280.png" width="90" align="center"/></td>
					<td align="center"><img src="../../../../../Downloads/Telefono.png" width="100px" align="center"/></td>
					<td align="center"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Facebook_f_logo_%282019%29.svg/1200px-Facebook_f_logo_%282019%29.svg.png" width="100px" align="center"/></td>
				</tr>
				
				<tr>
					<td class="contacto">World_ConnectionCR</td>
					<td class="contacto">+506 8654-3258</td>
					<td class="contacto">World Connection</td>
				</tr>
			</table>
		</footer>
		
	</body>
</html>