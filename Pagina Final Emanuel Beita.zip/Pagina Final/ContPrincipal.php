<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
	</head>
	<body>
		<a href="#main-header"><img class="botonSubir" src="https://cdn.pixabay.com/photo/2013/07/12/19/20/arrow-154593_640.png" /></a>
	
	<!--Primer contenedor de Informacion-->
		<div class="contenedor-1" id="main-header">
		
			<img class="img-box" src="https://jnretail.com/wp-content/uploads/slider/cache/ea958dbff72377ab4e0109c68132c0c7/gondolas-para-tiendas-de-informatica.webp"/>
			
			<div class="text-info1">
				<p>
				<b>¿Que es World Conecction?</b>
				<br/>
				World Conecction es una tienda constarricense que busca conectar al mundo por medio de la tecnologia y asi poder hacer realidad tus anelos. Ubicados en San Jose Curridabat para una mejos comodidad y cercania hacia nuestros clientes.
				</p>	
			</div>

		</div>
		
		<hr/>
		
		<!--Segundo contenedor de Informacion-->
		<div class="contenedor-2">
		
			<a href="CPU.html"><img class="img-box" src="https://media.istockphoto.com/id/1314343964/photo/top-end-system-unit-for-gaming-computer-close-up.jpg?s=612x612&w=0&k=20&c=d_xKRis8Ccy90gbqCjScpuAEVOvpQN0kdnBxA_H9zRs="/></a>
			
			<div class="text-info2">
				<p>
				<b>Tipos de PC que vendemos</b>
				<br/>
				Vendemos una amplia variedad de PC armados y personalizados, desde PC Gaming hasta dispocitovos efocados en cualquier otro objetivo que te imagines. Contamos con los componentes de ultima generacion que esta en el mercado para poder contruir nuestros dispositivos.
				</p>	
			</div>

		</div>
		
		<hr/>
		
		<!--Tercer contenedor de Informacion-->
		<div class="contenedor-3">
		
			<a href="Portatiles.html"><img class="img-box" src="https://images.unsplash.com/photo-1603302576837-37561b2e2302?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fGxhcHRvcCUyMGhwfGVufDB8fDB8fHww"/></a>
			
			<div class="text-info3">
				<p>
				<b>¿Que tipos de Portatiles manejamos?</b>
				<br/>
				En nuestra página web, ofrecemos una amplia gama de portátiles diseñados para satisfacer las necesidades de todo tipo de usuarios, desde estudiantes y profesionales hasta entusiastas de la tecnología. Nuestra selección incluye portátiles ultradelgados y ultraligeros ideales para la movilidad, así como potentes estaciones de trabajo para tareas intensivas. Además, contamos con portátiles versátiles que se adaptan a diferentes presupuestos y necesidades de rendimiento, junto con modelos especializados para gaming y creatividad. Independientemente de tus necesidades, estamos comprometidos a ofrecerte portátiles de alta calidad y rendimiento para mejorar tu experiencia informática.
				</p>	
			</div>

		</div>
		
		<hr/>
		
		<!--Cuarto contenedor de Informacion-->
		<div class="contenedor-4">
		
			<img class="img-box" src="https://jashtechperu.com.pe/wp-content/uploads/2022/08/perifericos-para-mi-pc-gamer.jpg"/>
			
			<div class="text-info4">
				<p>
				<b>Nuestro Objetivo</b>
				<br/>
				Nuestro objetivo es brindar a nuestros clientes no solo productos de alta calidad, sino también una experiencia de compra excepcional, donde puedan encontrar soluciones tecnológicas que se adapten perfectamente a sus necesidades y estilo de vida. Nos esforzamos por ser un punto de encuentro donde la innovación y la accesibilidad se unen, ofreciendo una amplia variedad de dispositivos electrónicos, desde portátiles y smartphones hasta accesorios y dispositivos inteligentes para el hogar. En World Connection, creemos en construir puentes entre las personas y la tecnología, facilitando conexiones significativas que enriquezcan la vida cotidiana y impulsen el progreso en la era digital.
				</p>	
			</div>

		</div>
		
		<footer class="pie-pagina">
			<table class="tabla-contactanos" align="center" cellspacing="40">
				<tr>
					<td align="center"><img src="https://cdn.pixabay.com/photo/2021/10/17/14/55/instagram-6718540_1280.png" width="90" align="center"/></td>
					<td align="center"><img src="../../../../../Downloads/Telefono.png" width="100px" align="center"/></td>
					<td align="center"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Facebook_f_logo_%282019%29.svg/1200px-Facebook_f_logo_%282019%29.svg.png" width="100px" align="center"/></td>
				</tr>
				
				<tr>
					<td class="contacto">World_ConnectionCR</td>
					<td class="contacto">+506 8654-3258</td>
					<td class="contacto">World Connection</td>
				</tr>
			</table>
		</footer>
	</body>
</html>