<?php
	$Conexion = @mysqli_connect("localhost","root","","site");
	
	if(@mysqli_connect_error()>0){
		
		echo("<h1>Error de conexion".@mysqli_connect_error()."</h1");
	}
?>