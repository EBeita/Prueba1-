<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" type="text/css" href="CSS/StylePortatiles.css"/>
	</head>
	<body>
	<a href="#main-header"><img class="botonSubir" src="https://cdn.pixabay.com/photo/2013/07/12/19/20/arrow-154593_640.png" /></a>
	<!--Empieza la Primera tabla-->
	
	<table>
		<tr>
			<td>
			
			<!--Primer contenedor de Informacion-->
		<div class="contenedor-1" id="main-header">
		
			<img class="img-box" src="https://btcr.cr/wp-content/uploads/2021/05/venta-de-portatiles-en-costa-rica-300x300.jpg"/>
			
			<div class="text-info1">
				<table class="tabla-precios">
					<tr>
						<td class="presio" align="center"><b>¢365.000</b></td>
					</tr>
					
					<tr>
						<td>Portatil Acer <br/>Exelentes componentes para estudiantes</td>
					</tr>	
					
					<tr>
						<td align="center" ><a href="Carrito.html"><img class="carrito" src="https://png.pngtree.com/png-clipart/20230811/original/pngtree-shopping-cart-icon-button-buy-add-vector-picture-image_10348063.png" width="80px"/></a></td>
					</tr>
				</table>	
			</div>

		</div>
		
			</td>
		
			<td>
				<!--Segundo contenedor de Informacion-->
		<div class="contenedor-2">
		
			<img class="img-box" src="https://www.intelec.co.cr/image/cache/catalog/catalogo/Portatiles/802C0LA-250x250w.jpg.webp"/>
			
			<div class="text-info2">
				<table class="tabla-precios">
					<tr>
						<td class="presio" align="center"><b>¢305.000</b></td>
					</tr>
					
					<tr>
						<td>Portatil HP <br/>4GB RAM - 1T Memoria</td>
					</tr>	
					
					<tr>
						<td align="center" ><a href="Carrito.html"><img class="carrito" src="https://png.pngtree.com/png-clipart/20230811/original/pngtree-shopping-cart-icon-button-buy-add-vector-picture-image_10348063.png" width="80px"/></a></td>
					</tr>
				</table>	
			</div>

		</div>
		
			</td>
			
			<td>
				<!--Tercera contenedor de Informacion-->
		<div class="contenedor-3">
		
			<img class="img-box" src="https://graffica.info/wp-content/uploads/2021/03/71lLXV9filL._AC_SL1200_-scaled.jpg"/>
			
			<div class="text-info2">
				<table class="tabla-precios">
					<tr>
						<td class="presio" align="center"><b>¢585.000</b></td>
					</tr>
					
					<tr>
						<td>Portatil Asus zenbook duo ux38 <br/> RAM de 6 GB - Pantalla 4K UHD</td>
					</tr>	
					
					<tr>
						<td align="center" ><a href="Carrito.html"><img class="carrito" src="https://png.pngtree.com/png-clipart/20230811/original/pngtree-shopping-cart-icon-button-buy-add-vector-picture-image_10348063.png" width="80px"/></a></td>
					</tr>
				</table>	
			</div>

		</div>
		
			</td>
		
		
		</tr>
	</table>
	
	<!--Termina primera tabla-->
	
	<hr>
	
	<!--Empieza segunda tabla-->
	<table>
		<tr>
			<td>
			
			<!--Primer contenedor de Informacion-->
		<div class="contenedor-1">
		
			<img class="img-box" src="https://cdn.grupoelcorteingles.es/SGFM/dctm/MEDIA03/202401/10/00115214807057____2__1200x1200.jpg?impolicy=Resize&width=900"/>
			
			<div class="text-info1">
				<table class="tabla-precios">
					<tr>
						<td class="presio" align="center"><b>¢205.000</b></td>
					</tr>
					
					<tr>
						<td>LENOVO <br/>Convertible 2 en 1 </td>
					</tr>	
					
					<tr>
						<td align="center" ><a href="Carrito.html"><img class="carrito" src="https://png.pngtree.com/png-clipart/20230811/original/pngtree-shopping-cart-icon-button-buy-add-vector-picture-image_10348063.png" width="80px"/></a></td>
					</tr>
				</table>	
			</div>

		</div>
		
			</td>
		
			<td>
				<!--Segundo contenedor de Informacion-->
		<div class="contenedor-2">
		
			<img class="img-box" src="https://www.bigbaydata.com/wp-content/uploads/2024/02/MSI-Bravo-17.webp"/>
			
			<div class="text-info2">
				<table class="tabla-precios">
					<tr>
						<td class="presio" align="center"><b>¢465.000</b></td>
					</tr>
					
					<tr>
						<td>MSI <br/>Portatil Gaminga</td>
					</tr>	
					
					<tr>
						<td align="center" ><a href="Carrito.html"><img class="carrito" src="https://png.pngtree.com/png-clipart/20230811/original/pngtree-shopping-cart-icon-button-buy-add-vector-picture-image_10348063.png" width="80px"/></a></td>
					</tr>
				</table>	
			</div>

		</div>
		
			</td>
			
			<td>
				<!--Tercera contenedor de Informacion-->
		<div class="contenedor-3">
		
			<img class="img-box" src="https://thumb.pccomponentes.com/w-530-530/articles/1081/10812222/1834-msi-cyborg-15-a13vf-879xes-intel-core-i7-13620h-32gb-1tb-ssd-rtx-4060-156-c61e902c-f640-48da-9f43-5bc595c18181.jpg"/>
			
			<div class="text-info2">
				<table class="tabla-precios">
					<tr>
						<td class="presio" align="center"><b>¢500.000</b></td>
					</tr>
					
					<tr>
						<td>Portatil Gaming MSI <br/>Corei7-12650H</td>
					</tr>	
					
					<tr>
						<td align="center" ><a href="Carrito.html"><img class="carrito" src="https://png.pngtree.com/png-clipart/20230811/original/pngtree-shopping-cart-icon-button-buy-add-vector-picture-image_10348063.png" width="80px"/></a></td>
					</tr>
				</table>	
			</div>

		</div>
		
			</td>
		
		
		</tr>
	</table>
	
	<!--Terminara la Tercera tabla-->
	
	<footer class="pie-pagina">
			<table class="tabla-contactanos" align="center" cellspacing="40">
				<tr>
					<td align="center"><img src="https://cdn.pixabay.com/photo/2021/10/17/14/55/instagram-6718540_1280.png" width="90" align="center"/></td>
					<td align="center"><img src="../../../../../Downloads/Telefono.png" width="100px" align="center"/></td>
					<td align="center"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Facebook_f_logo_%282019%29.svg/1200px-Facebook_f_logo_%282019%29.svg.png" width="100px" align="center"/></td>
				</tr>
				
				<tr>
					<td class="contacto">World_ConnectionCR</td>
					<td class="contacto">+506 8654-3258</td>
					<td class="contacto">World Connection</td>
				</tr>
			</table>
		</footer>
	</body>
</html>