<?php
	session_start();
	include_once("DBConexion.php");
	
	$Op="";
	$Resp=False;

	$txtUsr="";
	$txtapellido="";
	$numtel="";
	$corusr="";
	$pwdusr="";
	
	if(isset($_POST["txtUsr"])){
		$txtUsr = $_POST["txtUsr"];
	}
	
	if(isset($_POST["txtapellido"])){
		$txtapellido = $_POST["txtapellido"];
	}
	
	if(isset($_POST["numtel"])){
		$numtel = $_POST["numtel"];
	}
	
	if(isset($_POST["corusr"])){
		$corusr = $_POST["corusr"];
	}
	
	if(isset($_POST["pwdusr"])){
		$pwdusr = $_POST["pwdusr"];
	}
	
	if(isset($_POST["btnRegistro"])){
		
		$Op=1;
		$Dml="INSERT INTO Tienda(NomUsuario, ApeUsuario, TelUsuario, CorUsuario, PwdUsuario) ";
		$Dml.="VALUES('$txtUsr', '$txtapellido', '$numtel', '$corusr', '$pwdusr') ";
		
		$Resul= @mysqli_query($Conexion,$Dml);
		
		if(@mysqli_errno($Conexion)==0){
			$Resp=TRUE;
			header("Location:Principal.php");
		}
}

	$Sql="SELECT COUNT(*) AS Existe FROM Tienda ";
	$Sql.="WHERE NomUsuario = '$txtUsr' ";
	$Sql.="AND PwdUsuario = '$pwdusr' ";
	
	$Resul=@mysqli_query($Conexion, $Sql);
	$Fila=@mysqli_fetch_array($Resul, MYSQLI_ASSOC);
	
	if($txtUsr=="adminEma" && $pwdusr=="123"){
		setcookie("Login", "1", time()+30);
		$_SESSION["NomUsuario"]=$$txtUsr;
		header("Location:PrincipalAdmin.php");
		die();
	}
	else{
		setcookie("Login", "0", time()-30);
		session_unset();
		session_destroy();
		header("Location:LoginTienda.php");
		die();
	}
	

	if($Fila["Existe"]==1){
		setcookie("Login", "1", time()+30);
		$_SESSION["NomUsuario"]=$$txtUsr;
		header("Location:Principal.php");
		die();
	}
	else{
		setcookie("Login", "0", time()-30);
		session_unset();
		session_destroy();
		header("Location:LoginTienda.php");
		die();
	}
	
	
?>
	