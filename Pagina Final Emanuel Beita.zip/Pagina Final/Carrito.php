<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Carrito</title>
		<link rel="stylesheet" type="text/css" href="CSS/StyleCarrito.css"/>
	</head>
	<body>
	
	<a href="#main-header"><img class="botonSubir" src="https://cdn.pixabay.com/photo/2013/07/12/19/20/arrow-154593_640.png" /></a>
	
	<h1>Tu Carrito</h1>
	</body>
</html>