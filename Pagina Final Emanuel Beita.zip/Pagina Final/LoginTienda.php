<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Registrarse</title>
		<link rel="stylesheet" type="text/css" href="CSS/StyelLogin.css"/>
	</head>
	<body>
	<!--Imagen de fondo-->
		<img src="https://img.freepik.com/foto-gratis/pintura-lago-montana-montana-al-fondo_188544-9126.jpg?w=996&t=st=1711433550~exp=1711434150~hmac=acffc0f8ffdf97ef14b7d50f32c345084787571bf16f3de29e5a7068b62b0ba2" class="img-fondo"/>
	
	<!--Contenedor del area de registro-->	
		<div class="box-login">
		
			<img class="img-login" src="https://cdn-icons-png.flaticon.com/256/552/552721.png">--
		
			<form id="logintienda" name="logintienda" action="validacion.php" method="post">
			
				<table align="center" width="90%" cellpadding="15"> 
				
					<tr>
						<td align="center"><label>Nombre:</label></td>
						<td><input type="text" name="txtUsr" id="txtUsr" placeholder="Digite su nombre"/></td>
					</tr>
					
					<tr>
						<td align="center"><label>Apellidos:</label></td>
						<td><input type="text" name="txtapellido" id="txtapellido" placeholder="Digite su apellido"/></td>
					</tr>
					
					<tr>
						<td align="center"><label>Telefono:</label></td>
						<td><input type="number" name="numtel" id="numtel" placeholder="Digite su numero de telefono" /></td>
					</tr>
					
					<tr>
						<td align="center"><label>Correo:</label></td>
						<td><input type="text" name="corusr" id="corusr" placeholder="Digite su correo"/></td>
					</tr>
					
					<tr>
						<td align="center"><label>Contraceña:</label></td>
						<td><input type="password" name="pwdusr" id="pwdusr" placeholder="Digite su contraseña"/></td>
					</tr>
					
					<tr>
						<td><input class="boton" type="submit" name="btnRegistro" id="btnRegistro" placeholder="Registro"/></td>
						<td><input class="boton" type="submit" name="btnSesion" id="btnSesion" placeholder="Iniciar Secion"/></td>
					</tr>
					
				</table>
			</form>
			
			
		</div>
	<!--Termina el contenedor del registro-->
	</body>
</html>